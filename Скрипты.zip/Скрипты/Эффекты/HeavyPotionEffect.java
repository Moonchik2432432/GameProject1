package net.mcreator.weaponadventure.potion;

import net.minecraftforge.registries.ObjectHolder;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.potion.EffectType;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effect;
import net.minecraft.entity.LivingEntity;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class HeavyPotionEffect {
    @ObjectHolder("weapon_adventure:heavy")
    public static final Effect potion = null;

    @SubscribeEvent
    public static void registerEffect(RegistryEvent.Register<Effect> event) {
        event.getRegistry().register(new EffectCustom());
    }

    public static class EffectCustom extends Effect {
        public EffectCustom() {
            super(EffectType.HARMFUL, -1);
            setRegistryName("heavy");
        }

        @Override
        public String getName() {
            return "effect.heavy";
        }

        @Override
        public boolean isBeneficial() {
            return false;
        }

        @Override
        public boolean isInstant() {
            return false;
        }

        @Override
        public boolean shouldRenderInvText(EffectInstance effect) {
            return true;
        }

        @Override
        public boolean shouldRender(EffectInstance effect) {
            return true;
        }

        @Override
        public boolean shouldRenderHUD(EffectInstance effect) {
            return true;
        }

        @Override
        public boolean isReady(int duration, int amplifier) {
            return false; // не нужно вызывать performEffect
        }
    }
}
