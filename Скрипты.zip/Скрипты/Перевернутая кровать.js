function tick(e) {
e.block.setModel("minecraft:light_gray_bed")
e.block.setRotation(0,165,90)
}